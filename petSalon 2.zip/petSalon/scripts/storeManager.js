function saveItem(item){//function that sends the item to the local storage
    function saveltem(item, key){
        let itemsArray = readItems(); //getting l
        itemsArray.push(item);//add the new item
        Let val = JSONs.stringify (itemsArray); //
        localStorage.setItem(key,val);
    }

function readItems(){
    //getting items from local storage
    let data=localStorage.getItem("services");
    if(!data){//NOT data?
        return[];//creates the array        
    }else{
        //
    }
}